/*
 * 사진 회로 그대로: Arduino Uno R3(ATmega328P) 전용
 * LED: D13 / 버튼: D2-GND / 가변저항 가운데: A0
 * I2C LCD: SDA=A4, SCL=A5, VCC=5V, GND=GND
 * 웹에서 0~255 + 줄바꿈을 받습니다. 통신 속도: 9600 baud
 *
 * D13에는 일반 analogWrite PWM이 없으므로 Timer1 인터럽트로
 * 소프트웨어 PWM을 만듭니다. D9로 배선을 옮길 필요가 없습니다.
 * Timer1을 사용하는 Servo 등의 라이브러리와 함께 사용하지 마세요.
 * 라이브러리 관리자: LiquidCrystal I2C (Frank de Brabander) 설치
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <avr/interrupt.h>
#include <stdio.h>

#if !defined(__AVR_ATmega328P__) || F_CPU != 16000000UL
#error "Select Arduino Uno R3 (ATmega328P, 16 MHz)."
#endif

const byte LED_PIN = 13;
const byte BUTTON_PIN = 2;
const byte POT_PIN = A0;
const byte LCD_ADDRESS = 0x27;  // LCD가 0x3F 제품이면 0x3F로 변경
LiquidCrystal_I2C lcd(LCD_ADDRESS, 16, 2);
bool lcdFound = false;

volatile uint8_t ledBrightness = 0;
int potValue = 0;
char inputLine[16];
byte inputLength = 0;
bool lineTooLong = false;

// 16 MHz / 512 = 31,250회/초. 256단계 PWM 주파수는 약 122 Hz입니다.
// Uno의 D13은 PB5입니다. LCD 통신 중에도 LED 밝기를 유지합니다.
ISR(TIMER1_COMPA_vect) {
  static uint8_t phase = 0;
  const uint8_t value = ledBrightness;

  if (value == 0) {
    PORTB &= ~_BV(PB5);
  } else if (value == 255) {
    PORTB |= _BV(PB5);
  } else if (phase == 0) {
    PORTB |= _BV(PB5);
  } else if (phase == value) {
    PORTB &= ~_BV(PB5);
  }
  phase++;
}

void startLedPwm() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  const uint8_t savedSREG = SREG;
  cli();
  TCCR1A = 0;
  TCCR1B = 0;
  TCNT1 = 0;
  OCR1A = 511;
  TIFR1 = _BV(OCF1A);  // 남아 있는 비교 일치 플래그 지우기
  TIMSK1 = _BV(OCIE1A);
  TCCR1B = _BV(WGM12) | _BV(CS10);  // CTC 모드 / 분주 없음
  SREG = savedSREG;
}

void setBrightness(byte value) {
  ledBrightness = value;
  Serial.print("LED:");
  Serial.println(value);
}

void processLine() {
  if (inputLength == 0) return;
  unsigned int value = 0;
  for (byte i = 0; i < inputLength; i++) {
    if (inputLine[i] < '0' || inputLine[i] > '9') return;
    value = value * 10 + (inputLine[i] - '0');
    if (value > 255) return;
  }
  setBrightness((byte)value);
}

void receiveSerial() {
  while (Serial.available() > 0) {
    const char ch = Serial.read();
    if (ch == '\r') continue;
    if (ch == '\n') {
      if (!lineTooLong) processLine();
      inputLength = 0;
      lineTooLong = false;
    } else if (!lineTooLong) {
      if (inputLength < sizeof(inputLine) - 1) {
        inputLine[inputLength++] = ch;
      } else {
        lineTooLong = true;
      }
    }
  }
}

void readButton() {
  static byte lastReading = HIGH;
  static byte stableState = HIGH;
  static unsigned long changedAt = 0;
  const byte reading = digitalRead(BUTTON_PIN);

  if (reading != lastReading) changedAt = millis();
  if (millis() - changedAt >= 30 && reading != stableState) {
    stableState = reading;
    if (stableState == LOW) {
      // 버튼은 LED 끄기 기능입니다. 슬라이더를 다시 움직이면 켜집니다.
      Serial.println("BUTTON:0");
      setBrightness(0);
    }
  }
  lastReading = reading;
}

void refreshDisplay() {
  potValue = analogRead(POT_PIN);
  Serial.print("POT:");
  Serial.println(potValue);
  if (!lcdFound) return;

  char row[17];
  snprintf(row, sizeof(row), "LED:%3u / 255   ", (unsigned int)ledBrightness);
  lcd.setCursor(0, 0);
  lcd.print(row);
  snprintf(row, sizeof(row), "POT:%4d BTN:%d  ", potValue,
           digitalRead(BUTTON_PIN) == LOW ? 1 : 0);
  lcd.setCursor(0, 1);
  lcd.print(row);
}

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  Serial.begin(9600);
  startLedPwm();
  Wire.begin();
#if defined(WIRE_HAS_TIMEOUT)
  Wire.setWireTimeout(3000, true);
#endif

  Wire.beginTransmission(LCD_ADDRESS);
  lcdFound = Wire.endTransmission() == 0;
  if (lcdFound) {
    lcd.init();
    lcd.backlight();
    lcd.clear();
  }

  Serial.println("READY");
  setBrightness(0);
  refreshDisplay();
}

void loop() {
  receiveSerial();
  readButton();

  static unsigned long lastRefresh = 0;
  if (millis() - lastRefresh >= 200) {
    lastRefresh = millis();
    refreshDisplay();
  }
}
