// 슬라이더의 0~255 값을 아두이노로 보냅니다.
let serial, brightnessSlider, connectButton;
let statusText = 'USB 케이블을 연결한 뒤 Arduino 연결을 눌러 주세요.';
let actualBrightness = null;
let potValue = null;
let connecting = false;
let sendTimer = null;

function setup() {
  createCanvas(600, 320).parent('canvas-container');
  textFont('sans-serif');

  serial = new SerialHelper(9600, receiveLine, message => statusText = message);

  brightnessSlider = createSlider(0, 255, 0, 1);
  brightnessSlider.parent('slider-container');
  brightnessSlider.attribute('aria-label', 'LED 밝기 0부터 255');
  brightnessSlider.input(() => {
    // 드래그 중에도 약 40ms 간격으로 최신 값을 보냅니다.
    if (sendTimer === null) {
      sendTimer = setTimeout(() => {
        sendTimer = null;
        sendBrightness();
      }, 40);
    }
  });
  brightnessSlider.changed(sendBrightness);

  connectButton = createButton('Arduino 연결');
  connectButton.parent('button-container');
  connectButton.mousePressed(toggleConnection);

  if (!window.isSecureContext || !('serial' in navigator)) {
    statusText = 'PC용 Chrome/Edge에서 HTTPS 주소로 열어 주세요.';
    connectButton.attribute('disabled', '');
  }
}

function draw() {
  const value = Number(brightnessSlider.value());
  background(244, 247, 251);
  noStroke();
  textAlign(CENTER, CENTER);

  fill(25, 40, 60);
  textSize(22);
  text('p5.js 슬라이더 · LED 밝기 조절', width / 2, 34);

  // 화면의 원은 슬라이더 값에 대한 미리보기입니다.
  fill(lerpColor(color('#475569'), color('#fbbf24'), value / 255));
  circle(145, 154, 116);
  fill(value > 100 ? '#422006' : '#ffffff');
  textSize(25);
  text(round(value / 255 * 100) + '%', 145, 154);

  fill(25, 40, 60);
  textSize(17);
  text('슬라이더 값', 405, 110);
  textSize(38);
  text(value + ' / 255', 405, 154);
  textSize(14);
  const response = serial.connected && actualBrightness !== null
    ? actualBrightness + ' / 255' : '확인 전';
  text('아두이노 응답: ' + response, 405, 201);

  textSize(14);
  text('LED 미리보기', 145, 239);
  text('가변저항 A0: ' + (potValue === null ? '확인 전' : potValue + ' / 1023'), 405, 239);
  fill(serial.connected ? '#15803d' : '#64748b');
  textSize(13);
  text(serial.connected ? '● 연결됨 · D13 소프트웨어 PWM · 9600 baud' : '● 연결 안 됨 · 화면 미리보기만 동작', 300, 287);

  document.getElementById('status').textContent = statusText;
  if (!connecting) {
    connectButton.html(serial.connected ? 'Arduino 연결 해제' : 'Arduino 연결');
  }
}

async function toggleConnection() {
  if (connecting) return;
  connecting = true;
  connectButton.attribute('disabled', '');
  connectButton.html('처리 중…');

  try {
    if (serial.connected) {
      // 정상적으로 연결을 해제할 때 LED를 먼저 끕니다.
      await serial.send('0');
      await serial.disconnect();
      actualBrightness = null;
      brightnessSlider.value(0);
    } else {
      actualBrightness = null;
      if (await serial.connect()) await sendBrightness();
    }
  } finally {
    connecting = false;
    connectButton.removeAttribute('disabled');
  }
}

async function sendBrightness() {
  if (serial && serial.connected) {
    await serial.send(String(brightnessSlider.value()));
  }
}

function receiveLine(line) {
  const ledMatch = line.match(/^LED:(\d+)$/);
  const potMatch = line.match(/^POT:(\d+)$/);

  if (ledMatch) {
    const value = Number(ledMatch[1]);
    if (value >= 0 && value <= 255) actualBrightness = value;
  } else if (potMatch) {
    const value = Number(potMatch[1]);
    if (value >= 0 && value <= 1023) potValue = value;
  } else if (line === 'BUTTON:0') {
    // 회로의 버튼을 누르면 화면 슬라이더도 0으로 맞춥니다.
    if (sendTimer !== null) clearTimeout(sendTimer);
    sendTimer = null;
    brightnessSlider.value(0);
    actualBrightness = 0;
    // 대기 중인 이전 전송이 있더라도 마지막 명령을 0으로 만듭니다.
    sendBrightness();
    statusText = '회로의 버튼을 눌러 LED를 껐습니다. 슬라이더로 다시 조절하세요.';
  }
}
