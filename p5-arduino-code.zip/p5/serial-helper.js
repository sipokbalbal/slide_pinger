// Web Serial 연결, 줄 단위 수신, 연결 해제를 담당합니다.
class SerialHelper {
  constructor(baudRate, onLine, onStatus) {
    this.baudRate = baudRate;
    this.onLine = onLine;
    this.onStatus = onStatus;
    this.port = null;
    this.reader = null;
    this.writer = null;
    this.readTask = null;
    this.writeQueue = Promise.resolve();
    this.connected = false;
    this.disconnecting = false;
  }

  async connect() {
    if (this.connected) return true;
    if (!window.isSecureContext || !('serial' in navigator)) {
      this.onStatus('PC용 Chrome/Edge에서 HTTPS 주소로 열어 주세요.');
      return false;
    }

    // 이전 연결이 비정상 종료되었다면 먼저 정리합니다.
    if (this.port) await this.disconnect();

    try {
      this.onStatus('목록에서 Arduino의 USB 포트를 선택해 주세요.');
      this.port = await navigator.serial.requestPort();
      await this.port.open({ baudRate: this.baudRate });
      this.writer = this.port.writable.getWriter();
      this.reader = this.port.readable.getReader();
      this.readTask = this.readLines();

      // Uno는 포트를 열면 재시작할 수 있어 잠시 기다립니다.
      this.onStatus('Arduino가 준비되는 중입니다. 잠시 기다려 주세요.');
      await new Promise(resolve => setTimeout(resolve, 2000));
      if (!this.port || !this.reader || !this.writer) {
        throw new Error('USB 연결을 확인해 주세요.');
      }

      this.connected = true;
      this.onStatus('연결되었습니다. 슬라이더로 밝기를 조절하세요.');
      return true;
    } catch (error) {
      await this.disconnect();
      this.onStatus(error.name === 'NotFoundError'
        ? '포트 선택을 취소했습니다. 연결 버튼을 다시 눌러 주세요.'
        : '연결 실패: ' + error.message + ' (시리얼 모니터를 닫아 주세요.)');
      return false;
    }
  }

  async send(line) {
    if (!this.connected || !this.writer) return false;

    // 여러 명령이 동시에 들어와도 순서대로 전송합니다.
    this.writeQueue = this.writeQueue.catch(() => false).then(async () => {
      if (!this.connected || !this.writer) return false;
      await this.writer.write(new TextEncoder().encode(String(line) + '\n'));
      return true;
    });

    try {
      return await this.writeQueue;
    } catch (error) {
      this.onStatus('전송 실패: ' + error.message);
      return false;
    }
  }

  async readLines() {
    const decoder = new TextDecoder();
    let buffer = '';
    try {
      while (this.reader && !this.disconnecting) {
        const { value, done } = await this.reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let newline;
        while ((newline = buffer.indexOf('\n')) !== -1) {
          const line = buffer.slice(0, newline).trim();
          buffer = buffer.slice(newline + 1);
          if (line) this.onLine(line);
        }
        // 비정상 입력으로 버퍼가 무한히 커지는 것을 방지합니다.
        if (buffer.length > 512) buffer = '';
      }
    } catch (error) {
      if (!this.disconnecting) this.onStatus('수신 중 연결이 끊겼습니다.');
    } finally {
      if (this.reader) {
        this.reader.releaseLock();
        this.reader = null;
      }
      if (!this.disconnecting) {
        this.connected = false;
        // 읽기 작업이 끝난 다음 포트와 쓰기 잠금을 정리합니다.
        setTimeout(async () => {
          if (this.port && !this.disconnecting) {
            await this.disconnect();
            this.onStatus('연결이 끊겼습니다. USB를 확인한 뒤 다시 연결하세요.');
          }
        }, 0);
      }
    }
  }

  async disconnect() {
    if (this.disconnecting) return;
    this.disconnecting = true;
    this.connected = false;

    await this.writeQueue.catch(() => false);
    if (this.reader) {
      try { await this.reader.cancel(); } catch (_) {}
    }
    if (this.readTask) {
      try { await this.readTask; } catch (_) {}
      this.readTask = null;
    }
    if (this.writer) {
      try { this.writer.releaseLock(); } catch (_) {}
      this.writer = null;
    }
    if (this.port) {
      try { await this.port.close(); } catch (_) {}
      this.port = null;
    }
    this.disconnecting = false;
    this.onStatus('연결이 해제되었습니다.');
  }
}
